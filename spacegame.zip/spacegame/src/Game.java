import acm.graphics.GLabel;
import acm.graphics.GLine;
import acm.program.GraphicsProgram;
import acm.program.Program;
import svu.csc213.Dialog;
import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
/**Main class that handles spawning stuff*/
public class Game extends GraphicsProgram {
    //so everything can give info to the main game
    public static Game main = new Game();
    //whether the game is going or it is on the title screen
    private volatile boolean gameGoing = false;
    //current score
    public int score = 0;
    //high score
    private int highScore;
    //current number of columns and rows
    public int columns = 3;
    public int rows = 1;
    //basic width and height
    public double SPACE_SHIP_WIDTH;
    public double SPACE_SHIP_HEIGHT;
    //the main spaceship controlled by the keys
    private Spaceship goodGuy;
    //the border lines
    private ArrayList<GLine> borders = new ArrayList<>();
    //the labels counting the score and high score
    GLabel scoreCounter = new GLabel("Score: " + score);
    GLabel highScoreCounter = new GLabel("High score: " + highScore);
    //start and instruction buttons
    private JButton start = new JButton("Start");
    private JButton instructions = new JButton("Instructions");
    public static void main(String[] args) {
        //make sure there is a high score file and if there isn't set the high score to 0
        try {
            if (new File("./highscore.txt").createNewFile()){
                FileWriter writer = new FileWriter(new File("./highscore.txt"));
                writer.write("0");
                writer.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        //start the window
        main.start();
    }
    public void run(){
        //make sure the window is in full screen
        GLabel l = new GLabel("Please fullscreen");
        add(l,getWidth()/2,getHeight()/2);
        //initialize everything that only needs to be initialized once
        scoreCounter.setColor(Color.GREEN);
        scoreCounter.setFont(new Font(scoreCounter.getFont().getFontName(),Font.PLAIN,32));
        highScoreCounter.setColor(Color.GREEN);
        highScoreCounter.setFont(new Font(highScoreCounter.getFont().getFontName(),Font.PLAIN,32));
        while(getWidth() < 1000){

        }
        //remove the please fullscreen label
        remove(l);
        try {
            highScore = new Scanner(new File("./highscore.txt")).nextInt();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //add the start and instruction buttons
        add(start, Program.SOUTH);
        start.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //set the game going to true
                gameGoing = true;
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        add(instructions, Program.SOUTH);
        instructions.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //show all the instructions
                Dialog.showMessage("This is a game called spaceship pirates by 83ben38.");
                Dialog.showMessage("The goal is to avoid getting hit by spaceships, and plunder as many spaceships as possible.");
                Dialog.showMessage("Arrow keys to move. \nYour spaceship is the blue one. \nIt can only go in complete white squares.");
                Dialog.showMessage("Space to shoot. \nRed and Orange spaceships are invulnerable to your bullets. \nYellow, Cyan, and Green spaceships can take 1, 2 and 3 respectively. \n Each enemy you kill will give you one point.");
                Dialog.showMessage("Z to rotate counterclockwise. \nX to rotate clockwise. \nYour spaceship will shoot in the direction it is facing.");
                Dialog.showMessage("Have fun!");
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        highScoreCounter.setLabel("High score: " + highScore);
        //add the controls
        addKeyListeners();
        //set the background to black
        setBackground(Color.black);
        //go
        go();
    }
    /**go back to the title screen*/
    public void go(){
        //reset everything
        columns = 3;
        rows = 1;
        start.setVisible(true);
        instructions.setVisible(true);
        //add the title
        GLabel l = new GLabel("Spaceship Pirates");
        l.setFont(new Font(l.getFont().getFontName(),Font.PLAIN,48));
        l.setColor(Color.green);
        add(l,getWidth()/2-l.getWidth()/2,getHeight()/2-l.getHeight()/2);
        //wait until the start button is pressed
        while(!gameGoing){

        }
        //remove the title screen and buttons
        remove(l);
        start.setVisible(false);
        instructions.setVisible(false);
        //start the game
        startGame();
    }
    /**spawn a wave based on difficulty, and which directions to spawn them from*/
    private void spawnDudes(int difficulty, boolean down, boolean left, boolean right){
        //randomize the difficulty slightly
        difficulty += randomInt(-1,1);
        //spawn all the spaceships, getting less hard each time
        spawnSingle("down",difficulty);
        if (down){
            difficulty-= 3;
            spawnSingle("up",difficulty);
            if (left){
                difficulty-= 3;
                spawnSingle("right",difficulty);
                if (right){
                    difficulty-= 3;
                    spawnSingle("left",difficulty);
                }
            }
        }
    }
    /**spawn enemies from a single direction*/
    private void spawnSingle(String direction, int difficulty){
        //array of which columns or rows have been spawned
        boolean[] spawned;
        if (direction.equals("up") || direction.equals("down")){
            spawned = new boolean[columns];
        }
        else{
            spawned = new boolean[rows];
        }
        //at the start, none have anything
        Arrays.fill(spawned, false);
        //amount spawned
        int spawnedAmount = 0;
        //one spawned per 5 difficulty with max at one less than the total slots
        while (difficulty > (spawnedAmount+1)*5 && spawnedAmount < spawned.length-1){
            String type = "red";
            //once difficulty 13 is hit, there is a 1 in 3 chance for each ship to be orange
            if (difficulty > 12 && randomInt(1,3) == 1){
                type = "orange";
            }
            int spawner = randomInt(0,spawned.length-1);
            while (spawned[spawner]){
                spawner = randomInt(0,spawned.length-1);
            }
            spawned[spawner] = true;
            switch (direction) {
                case "down" -> add(new Spaceship(type, direction), 300 + SPACE_SHIP_WIDTH * spawner, 1);
                case "up" -> add(new Spaceship(type, direction), 300 + SPACE_SHIP_WIDTH * spawner, getHeight() - SPACE_SHIP_HEIGHT);
                case "right" -> add(new Spaceship(type, direction), 1, 300 + SPACE_SHIP_WIDTH * spawner);
                case "left" -> add(new Spaceship(type, direction), getHeight() - SPACE_SHIP_HEIGHT, 300 + SPACE_SHIP_WIDTH * spawner);
            }
            spawnedAmount++;
        }
        //one hittable ship per round
        String type = "gold";
        //at difficulty 8 there is a 1 in 3 chance for a multi-hit ship
        if (difficulty > 7 && randomInt(1,3) == 1){
            if (randomInt(1,2) == 1){
                type = "cyan";
            }
            else{
                type = "green";
            }
        }
        int spawner = randomInt(0,spawned.length-1);
        while (spawned[spawner]){
            spawner = randomInt(0,spawned.length-1);
        }
        switch (direction) {
            case "down" -> add(new Spaceship(type, direction), 300 + SPACE_SHIP_WIDTH * spawner, 1);
            case "up" -> add(new Spaceship(type, direction), 300 + SPACE_SHIP_WIDTH * spawner, getHeight() - SPACE_SHIP_HEIGHT);
            case "right" -> add(new Spaceship(type, direction), 1, 300 + SPACE_SHIP_WIDTH * spawner);
            case "left" -> add(new Spaceship(type, direction), getHeight() - SPACE_SHIP_HEIGHT, 300 + SPACE_SHIP_WIDTH * spawner);
        }
    }
    /**start the game*/
    private void startGame(){
        try {
            Robot focuser = new Robot();
            focuser.mouseMove(getWidth()/2,getHeight()/2);
            focuser.mousePress(MouseEvent.BUTTON1_DOWN_MASK);
            focuser.mouseRelease(MouseEvent.BUTTON1_DOWN_MASK);
        } catch (AWTException e) {
            e.printStackTrace();
        }
        //add all the game things
        score = 0;
        add(scoreCounter,getWidth()/2-scoreCounter.getWidth()/2,scoreCounter.getHeight());
        add(highScoreCounter,getWidth()/2-highScoreCounter.getWidth()/2,highScoreCounter.getHeight()*2);
        goodGuy = new Spaceship();
        SPACE_SHIP_WIDTH = goodGuy.getWidth();
        SPACE_SHIP_HEIGHT = goodGuy.getHeight();
        add(goodGuy,300,300);
        resetLines();
        //start spawning stars
        new Thread(this::spawnStars).start();
        //difficulty starts at 3 and level at 1
        int difficulty = 3;
        int level = 1;
        //continue spawning until the game is over
        while (gameGoing) {
            //each level unlocks a new direction in which enemies come
            spawnDudes(difficulty, level > 1, level > 2, level > 3);
            //pause for 1 second plus 1 quarter for each wave
            for (int i = 0; i < 100 + difficulty*25; i++) {
                if (gameGoing) {
                    pause(10);
                    scoreCounter.setLabel("Score: " + score);
                }
            }
            if (gameGoing) {
                //increase the difficulty every wave
                difficulty++;
                //once the difficulty hits the correct amount, move on to the next level
                if (difficulty > 10 + (level * 5) && level < 5) {
                    Dialog.showMessage("You beat level " + level + "!");
                    level++;
                    //first level adds a column, second two rows, and the rest a column and a row
                    if (level == 2) {
                        columns++;
                    } else if (level == 3) {
                        rows += 2;
                    } else {
                        rows++;
                        columns++;
                    }
                    resetLines();
                    difficulty = 3;
                }
            }
        }
    }
    /**start spawning stars until the game is over*/
    private void spawnStars(){
        //spawn 20 stars every second
        while(gameGoing){
            new Star();
            pause(50);
        }
    }
    /** go back to the title screen when you lose*/
    public void gameOver(){
        //get rid of everything
        gameGoing = false;
        while(getElementCount() > 0){
            remove(getElement(0));
        }
        Dialog.showMessage("Game over! Your score: " + score + ".");
        //check for a new highscore
        if (score >= highScore){
            try {
                new File("./highscore.txt").delete();
                new File("./highscore.txt").createNewFile();
                FileWriter writer = new FileWriter("./highscore.txt");
                writer.write(String.valueOf(score));
                writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            highScore = score;
            highScoreCounter.setLabel("High score:" + highScore);
            Dialog.showMessage("Congrats on getting a new high score!");
        }
        go();
    }
    /**returns a random int in between from and to*/
    public static int randomInt(int from, int to){
        return (int)(Math.random()*(to-from+1))+from;
    }
    @Override
    public void keyReleased(KeyEvent e){
        //detect things upon key released
        if (gameGoing) {
            //space is shoot bullet
            if (e.getKeyChar() == ' ') {
                goodGuy.shootBullet();
            }
            //z and x are rotate
            if (e.getKeyChar() == 'z') {
                goodGuy.turn(false);
            }
            if (e.getKeyChar() == 'x') {
                goodGuy.turn(true);
            }
            //up down left and right are move
            if (e.getKeyCode() == 37) {
                Runnable thread = () -> goodGuy.move(false, -1);
                new Thread(thread).start();
            }
            if (e.getKeyCode() == 39) {
                Runnable thread = () -> goodGuy.move(false, 1);
                new Thread(thread).start();
            }
            if (e.getKeyCode() == 38) {
                Runnable thread = () -> goodGuy.move(true, -1);
                new Thread(thread).start();
            }
            if (e.getKeyCode() == 40) {
                Runnable thread = () -> goodGuy.move(true, 1);
                new Thread(thread).start();
            }
        }
    }
    /**resets the border lines*/
    private void resetLines(){
        //clear the border lines and re-add them
        while (borders.size() > 0){
            remove(borders.get(0));
            borders.remove(0);
        }
        for (int i = 0; i < columns+1; i++) {
            GLine line = new GLine(300+ SPACE_SHIP_WIDTH *i,0,300+ SPACE_SHIP_WIDTH *i,getHeight());
            line.setColor(Color.white);
            add(line);
            borders.add(line);
        }
        for (int i = 0; i < rows+1; i++) {
            GLine line = new GLine(0,300+ SPACE_SHIP_WIDTH *i,getWidth(),300+ SPACE_SHIP_WIDTH *i);
            line.setColor(Color.white);
            add(line);
            borders.add(line);
        }
    }
}
