import acm.graphics.GCompound;
import acm.graphics.GObject;
import acm.graphics.GOval;

import java.awt.*;
/**bullets shot by spaceships*/
public class Bullet extends GCompound {
    /**The visual*/
    private GOval projectile;
    /**which direction to go*/
    private String direction;
    /**whether it is a enemy or not*/
    private boolean enemy;
    /**shoot a bullet from the specified spaceship*/
    public Bullet(Spaceship s){
        enemy = s.enemy;
        projectile = new GOval(7,7);
        projectile.setFilled(true);
        if (enemy) {
            projectile.setFillColor(Color.red);
        }
        else{
            projectile.setFillColor(Color.blue);
        }
        add(projectile);
        Game.main.add(this,s.getX()+s.getWidth()/2,s.getY()+s.getHeight()/2);
        direction = s.direction;
        new Thread(this::move).start();
    }
    /**start moving*/
    public void move(){
        while (getY() > 0 && getY() < Game.main.getHeight() && getX() > 0 && getX() < Game.main.getWidth()) {
            GObject o = null;
            if (direction.equals("up")) {
                move(0, -3);
                o = Game.main.getElementAt(getX(),getY()-3);
            }
            if (direction.equals("down")) {
                move(0, 3);
                o = Game.main.getElementAt(getX(),getY()+3);
            }
            if (direction.equals("left")) {
                move(-3, 0);
                o = Game.main.getElementAt(getX()-3,getY());
            }
            if (direction.equals("right")) {
                move(3, 0);
                o = Game.main.getElementAt(getX()+3,getY());
            }
            if (enemy){
                if (o instanceof Spaceship){
                    if (!((Spaceship) o).enemy){
                        Game.main.gameOver();
                    }
                }
            }
            else{
                if (o instanceof Spaceship){
                    if (((Spaceship) o).enemy && ((Spaceship) o).type.equals("gold") || ((Spaceship) o).type.equals("cyan") || ((Spaceship) o).type.equals("green")){
                        ((Spaceship) o).loseLife();
                        break;
                    }
                }
            }
            pause(10);
        }
        Game.main.remove(this);
    }
}
