import acm.graphics.GOval;

import java.awt.*;
/**stars in the background*/
public class Star extends GOval {
    /**make a star of the specified size*/
    public Star(int size){
        super(size,size);
        this.setFilled(true);
        this.setFillColor(Color.white);
        this.setLocation(randomInt(0, Game.main.getWidth()),0);
        Game.main.add(this);
        new Thread(this::move).start();
        sendToBack();
        sendForward();
    }
    /**make a star with a random size*/
    public Star(){
        this(randomInt(3,7));
    }
    /**returns a random int in between from and to*/
    public static int randomInt(int from, int to){
        return (int)(Math.random()*(to-from+1))+from;
    }
    /**move from the top to the bottom of the screen*/
    private void move(){
        while(this.getY() < Game.main.getHeight()){
            move(0,1);
            pause(this.getWidth());
        }
        Game.main.remove(this);
    }
}
