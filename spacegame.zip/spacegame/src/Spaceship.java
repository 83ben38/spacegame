import acm.graphics.GCompound;
import acm.graphics.GImage;
import acm.graphics.GObject;
/**all the spaceships and their visuals*/
public class Spaceship extends GCompound {
    //type of spaceship (color)
    public final String type;
    //the image that is the spaceship
    private GImage i;
    //which direction it is pointing
    public String direction;
    //whether it is an enemy or not
    public boolean enemy;
    //amount of life left
    private int life = 1;
    //the x and the y of the main spaceship
    private int x;
    private int y;
    /**Make an enemy spaceship with the type and direction specified*/
    public Spaceship(String type, String direction){
        i = new GImage("./"+type+"_"+direction+".png");
        add(i);
        this.type = type;
        this.direction = direction;
        enemy = true;
        setLife();
        if (Game.main.SPACE_SHIP_WIDTH > 0) {
            if (direction.equals("up") || direction.equals("down")) {
                i.setSize(Game.main.SPACE_SHIP_WIDTH, Game.main.SPACE_SHIP_HEIGHT);
            }
            else{
                i.setSize(Game.main.SPACE_SHIP_HEIGHT, Game.main.SPACE_SHIP_WIDTH);
            }
        }
        new Thread(this::move).start();
    }
    /**Make the main spaceship*/
    public Spaceship(){
        this("blue","up");
        enemy = false;
        x = 0;
        y = 0;
    }
    /**turning for the main spaceship clockwise or counterclockwise*/
    public void turn(boolean clockwise){
        if (clockwise){
            if (direction.equals("up")){
                direction = "right";
            }
            else if (direction.equals("right")){
                direction = "down";
            }
            else if (direction.equals("down")){
                direction = "left";
            }
            else if (direction.equals("left")){
                direction = "up";
            }
        }
        else{
            if (direction.equals("up")){
                direction = "left";
            }
            else if (direction.equals("right")){
                direction = "up";
            }
            else if (direction.equals("down")){
                direction = "right";
            }
            else if (direction.equals("left")){
                direction = "down";
            }
        }
        remove(i);
        i = new GImage("./"+type+"_"+direction+".png");
        add(i);
        if (direction.equals("up") || direction.equals("down")) {
            i.setSize(Game.main.SPACE_SHIP_WIDTH, Game.main.SPACE_SHIP_HEIGHT);
        }
        else{
            i.setSize(Game.main.SPACE_SHIP_HEIGHT, Game.main.SPACE_SHIP_WIDTH);
        }
    }
    /**moving for the main spaceship, whether in the x or y direction and how much to move*/
    public void move(boolean upward, int amount){
        if (upward){
            if ((y > 0 && amount < 0) || (y < Game.main.rows-1 && amount > 0)) {
                y+=amount;
                for (int j = 0; j < 100; j++) {
                    move(0, Game.main.SPACE_SHIP_HEIGHT / 100 * amount);
                    pause(3);
                }
            }
        }
        else{
            if ((x > 0 && amount < 0) || (x < Game.main.columns-1 && amount > 0)) {
                x+=amount;
                for (int j = 0; j < 100; j++) {
                    move(Game.main.SPACE_SHIP_WIDTH / 100 * amount, 0);
                    pause(3);
                }
            }
        }
    }
    /**moving for enemy spaceships*/
    public void move(){
        while (getY() > -10 && getY() < Game.main.getHeight()+10 && getX() > -10 && getX() < Game.main.getWidth()+10 && enemy && life > 0) {
            GObject o = null;
            if (direction.equals("up")) {
                move(0, -2);
                o = Game.main.getElementAt(getX()+getWidth()/2,getY()-2);
            }
            if (direction.equals("down")) {
                move(0, 2);
                o = Game.main.getElementAt(getX()+getWidth()/2,getY()+getHeight()+2);
            }
            if (direction.equals("left")) {
                move(-2, 0);
                o = Game.main.getElementAt(getX()-2,getY()+getHeight()/2);
            }
            if (direction.equals("right")) {
                move(2, 0);
                o = Game.main.getElementAt(getX()+getWidth()+2,getY()+getHeight()/2);
            }
            if (enemy){
                if (o instanceof Spaceship){
                    if (!((Spaceship) o).enemy){
                        Game.main.gameOver();
                    }
                }
            }
            if (type.equals("orange") && Game.randomInt(1,100) == 1){
                new Bullet(this);
            }
            pause(10);
        }
        if (enemy){
            Game.main.remove(this);
        }
    }
    /**lose a life and check if you are dead*/
    public void loseLife(){
        life--;
        if (life < 1){
            Game.main.score++;
            Game.main.remove(this);
        }
    }
    /**reset your life*/
    public void setLife(){
        if (type.equals("cyan")){
            life = 2;
        }
        if (type.equals("yellow")){
            life = 1;
        }
        if (type.equals("green")){
            life = 3;
        }
    }
    /**shoot a bullet*/
    public void shootBullet(){
        new Bullet(this);
    }
}
